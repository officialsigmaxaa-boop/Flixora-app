package com.flixora.app

import android.content.Context
import android.app.DownloadManager
import android.os.Environment
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Bg = Color(0xFF080910)
private val SurfaceDark = Color(0xFF131522)
private val Muted = Color(0xFF9AA0B5)
private val Purple = Color(0xFF9B6CFF)
private val Cyan = Color(0xFF48DDF5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FlixoraApp(this) }
    }
}

data class PublicVideo(
    val id: String,
    val title: String,
    val creator: String,
    val year: String,
    val description: String,
    val licenseUrl: String,
    val streamUrl: String? = null,
    val downloadUrl: String? = null,
    val thumbnailUrl: String = "https://archive.org/services/img/$id"
) {
    val downloadAllowed: Boolean
        get() = licenseUrl.contains("creativecommons.org/licenses/by/", true) ||
            licenseUrl.contains("creativecommons.org/licenses/by-sa/", true) ||
            licenseUrl.contains("creativecommons.org/publicdomain/", true) ||
            licenseUrl.contains("creativecommons.org/publicdomain/zero/", true) ||
            licenseUrl.contains("creativecommons.org/licenses/by/4.0", true) ||
            licenseUrl.contains("creativecommons.org/licenses/by-sa/4.0", true) ||
            licenseUrl.contains("creativecommons.org/publicdomain/mark/1.0", true)
}

object InternetArchive {
    fun search(term: String): List<PublicVideo> {
        val q = if (term.isBlank()) "mediatype:movies AND licenseurl:*" else
            "mediatype:movies AND licenseurl:* AND (title:(${term}) OR creator:(${term}) OR subject:(${term}))"
        val fields = "identifier,title,creator,year,description,licenseurl"
        val endpoint = "https://archive.org/advancedsearch.php?q=${enc(q)}&fl[]=${enc("identifier")}" +
            "&fl[]=${enc("title")}&fl[]=${enc("creator")}&fl[]=${enc("year")}" +
            "&fl[]=${enc("description")}&fl[]=${enc("licenseurl")}&rows=30&page=1&output=json"
        val json = getJson(endpoint)
        val docs = json.optJSONObject("response")?.optJSONArray("docs") ?: return emptyList()
        val list = mutableListOf<PublicVideo>()
        for (i in 0 until docs.length()) {
            val d = docs.optJSONObject(i) ?: continue
            val id = d.optString("identifier")
            if (id.isBlank()) continue
            val lic = d.optString("licenseurl")
            if (lic.isBlank()) continue
            list.add(PublicVideo(
                id = id,
                title = d.optString("title", "Untitled video"),
                creator = d.optString("creator", "Internet Archive contributor"),
                year = d.optString("year", ""),
                description = d.optString("description", ""),
                licenseUrl = lic
            ))
        }
        return list
    }

    fun resolve(video: PublicVideo): PublicVideo {
        val meta = getJson("https://archive.org/metadata/${enc(video.id)}")
        val files = meta.optJSONArray("files") ?: return video
        var mp4: String? = null
        var best: String? = null
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name")
            val format = f.optString("format")
            if (name.endsWith(".mp4", true) || format.contains("MPEG4", true)) {
                if (f.optString("source") != "original" && f.optString("private") != "true") {
                    mp4 = name
                    break
                }
                if (mp4 == null) mp4 = name
            }
            if (name.endsWith(".ogv", true) && best == null) best = name
        }
        val file = mp4 ?: best ?: return video
        val url = "https://archive.org/download/${enc(video.id)}/${file.split("/").joinToString("/") { enc(it) }}"
        return video.copy(streamUrl = url, downloadUrl = if (video.downloadAllowed && mp4 != null) url else null)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun getJson(address: String): JSONObject {
        val conn = URL(address).openConnection() as HttpURLConnection
        conn.connectTimeout = 12000
        conn.readTimeout = 16000
        conn.setRequestProperty("User-Agent", "FlixoraAndroid/1.0 (public catalog client)")
        return try {
            conn.inputStream.bufferedReader().use { JSONObject(it.readText()) }
        } finally { conn.disconnect() }
    }
}

@Composable
fun FlixoraApp(context: Context) {
    var selected by remember { mutableStateOf("Home") }
    var activeVideo by remember { mutableStateOf<PublicVideo?>(null) }
    var results by remember { mutableStateOf<List<PublicVideo>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var searchText by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun search(term: String = "") {
        loading = true; error = null
        scope.launch {
            try {
                val found = withContext(Dispatchers.IO) { InternetArchive.search(term) }
                results = found
                if (found.isEmpty()) error = "No openly licensed results found. Try another search."
            } catch (e: Exception) {
                error = "Could not reach the public catalog. Check your connection and try again."
            } finally { loading = false }
        }
    }

    LaunchedEffect(Unit) { search("") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = SurfaceDark, primary = Purple,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when {
                activeVideo != null -> PublicPlayerScreen(context, activeVideo!!,
                    onBack = { activeVideo = null },
                    onResolve = {
                        scope.launch {
                            loading = true
                            try {
                                activeVideo = withContext(Dispatchers.IO) { InternetArchive.resolve(activeVideo!!) }
                                if (activeVideo?.streamUrl == null)
                                    Toast.makeText(context, "No supported MP4 stream found for this item.", Toast.LENGTH_LONG).show()
                            } catch (_: Exception) {
                                Toast.makeText(context, "Could not load this video.", Toast.LENGTH_LONG).show()
                            } finally { loading = false }
                        }
                    },
                    onDownload = { v ->
                        val url = v.downloadUrl
                        if (url == null) Toast.makeText(context, "This item has no recognized download-permitting license.", Toast.LENGTH_LONG).show()
                        else {
                            try {
                                val safeName = (v.title.take(48).replace(Regex("[^A-Za-z0-9._-]"), "_")
                                    .ifBlank { v.id }) + ".mp4"
                                val request = DownloadManager.Request(Uri.parse(url))
                                    .setTitle(v.title)
                                    .setDescription("Flixora offline video · ${v.licenseUrl}")
                                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Flixora/$safeName")
                                    .setAllowedOverMetered(true)
                                    .setAllowedOverRoaming(false)
                                val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                manager.enqueue(request)
                                Toast.makeText(context, "Download started. Check Android Downloads.", Toast.LENGTH_LONG).show()
                            } catch (_: Exception) {
                                Toast.makeText(context, "Download could not be started on this device.", Toast.LENGTH_LONG).show()
                            }
                        }
                    })
                else -> Scaffold(
                    containerColor = Bg,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF0E101A), tonalElevation = 0.dp) {
                            listOf("Home", "Shorts", "Explore", "Downloads", "Library").forEach { label ->
                                val icon = when (label) {
                                    "Home" -> Icons.Filled.Home
                                    "Shorts" -> Icons.Filled.PlayCircle
                                    "Explore" -> Icons.Filled.Explore
                                    "Downloads" -> Icons.Filled.Download
                                    else -> Icons.Filled.VideoLibrary
                                }
                                NavigationBarItem(
                                    selected = selected == label, onClick = { selected = label },
                                    icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Purple, selectedTextColor = Color.White,
                                        indicatorColor = Purple.copy(alpha = .16f),
                                        unselectedIconColor = Muted, unselectedTextColor = Muted
                                    )
                                )
                            }
                        }
                    }
                ) { pad ->
                    Column(Modifier.fillMaxSize().padding(pad)) {
                        TopBar()
                        when (selected) {
                            "Home" -> PublicHome(results, loading, error, searchText,
                                onSearchText = { searchText = it },
                                onSearch = { search(searchText) },
                                onRefresh = { search("") },
                                onVideo = { activeVideo = it })
                            "Explore" -> ExploreScreen(onCategory = { search(it) ; selected = "Home" })
                            "Shorts" -> ShortsScreen()
                            "Downloads" -> DownloadsScreen()
                            else -> LibraryScreen()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp))
            .background(Brush.linearGradient(listOf(Purple, Cyan))), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.PlayArrow, null, tint = Color.White)
        }
        Spacer(Modifier.width(10.dp))
        Text("FLIXORA", fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Spacer(Modifier.weight(1f))
        Icon(Icons.Filled.Public, null, tint = Cyan, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text("OPEN VIDEO", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun PublicHome(
    videos: List<PublicVideo>, loading: Boolean, error: String?, query: String,
    onSearchText: (String) -> Unit, onSearch: () -> Unit, onRefresh: () -> Unit,
    onVideo: (PublicVideo) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Discover", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Openly licensed films & videos", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Filled.Refresh, "Refresh catalog", tint = Muted) }
        }
        Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query, onValueChange = onSearchText,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Search public videos…", fontSize = 13.sp) },
                singleLine = true, shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple, unfocusedBorderColor = SurfaceDark,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White
                )
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onSearch, modifier = Modifier.size(52.dp).clip(RoundedCornerShape(15.dp)).background(Purple)) {
                Icon(Icons.Filled.Search, "Search", tint = Color.White)
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Purple, trackColor = SurfaceDark)
        if (error != null) Text(error, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(18.dp))
        if (videos.isEmpty() && !loading && error == null) {
            Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Language, null, tint = Purple, modifier = Modifier.size(42.dp))
                Text("Connecting to the open archive", fontWeight = FontWeight.SemiBold)
                Text("Tap refresh to discover public-domain and Creative Commons videos.", color = Muted, fontSize = 12.sp)
            }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
            items(videos, key = { it.id }) { v -> PublicVideoCard(v, onClick = { onVideo(v) }) }
        }
    }
}

@Composable
fun PublicVideoCard(video: PublicVideo, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp)) {
        Box(Modifier.fillMaxWidth().height(178.dp).clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF29205C), Color(0xFF176D82), Color(0xFF171827))))) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.PlayCircle, null, tint = Color.White, modifier = Modifier.size(48.dp))
                Text("INTERNET ARCHIVE", color = Color.White.copy(alpha = .75f), fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
            Text("OPEN LICENSE", Modifier.align(Alignment.TopStart).padding(12.dp)
                .clip(RoundedCornerShape(5.dp)).background(Color.Black.copy(alpha = .35f)).padding(7.dp),
                color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        Text(video.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 9.dp))
        Text("${video.creator}  ·  ${video.year}", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        Text("License: ${video.licenseUrl.substringAfterLast("/").ifBlank { "See item details" }}",
            color = Cyan.copy(alpha = .85f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun PublicPlayerScreen(context: Context, video: PublicVideo, onBack: () -> Unit,
                       onResolve: () -> Unit, onDownload: (PublicVideo) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
            Text("Now playing", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { onDownload(video) }) { Icon(Icons.Filled.Download, "Download") }
        }
        if (video.streamUrl == null) {
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.PlayCircle, null, tint = Purple, modifier = Modifier.size(54.dp))
                    Text("Load public video", fontWeight = FontWeight.Bold)
                    Button(onClick = onResolve) { Text("Find playable file") }
                }
            }
        } else {
            val player = remember(video.streamUrl) {
                ExoPlayer.Builder(context).build().apply {
                    setMediaItem(MediaItem.fromUri(video.streamUrl!!))
                    prepare()
                    playWhenReady = true
                }
            }
            DisposableEffect(player) { onDispose { player.release() } }
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            )
        }
        Column(Modifier.padding(18.dp)) {
            Text(video.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("${video.creator}  ·  ${video.year}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(12.dp))
            Text("License and source", color = Cyan, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(video.licenseUrl, color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            Text(video.description.take(500).ifBlank { "No description supplied by the archive contributor." },
                color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Text("Content is supplied by Internet Archive contributors. Check the item page and license terms before reuse or redistribution.",
                color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun ExploreScreen(onCategory: (String) -> Unit) {
    val categories = listOf("Animation", "Documentary", "Science", "History", "Music", "Technology", "Travel", "Education")
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Explore", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Browse public archive collections.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        categories.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { item ->
                    Column(Modifier.weight(1f).padding(end = 10.dp, bottom = 12.dp)
                        .clip(RoundedCornerShape(18.dp)).background(SurfaceDark).clickable { onCategory(item) }.padding(18.dp)) {
                        Icon(Icons.Filled.Explore, null, tint = Purple)
                        Spacer(Modifier.height(16.dp))
                        Text(item, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun ShortsScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Filled.Swipe, null, tint = Purple, modifier = Modifier.size(52.dp))
        Text("Shorts", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Vertical short-form clips will appear here as the public catalog adds suitable short videos.", color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun DownloadsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Downloads", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(24.dp)).background(SurfaceDark), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.DownloadForOffline, null, tint = Purple, modifier = Modifier.size(50.dp))
                Text("Your offline space", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Only items with recognized download permissions qualify.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun LibraryScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Your Library", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        listOf("History", "Playlists", "Liked videos", "Subscriptions", "Creator Studio").forEach { title ->
            Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.VideoLibrary, null, tint = Purple)
                Text(title, modifier = Modifier.weight(1f).padding(start = 14.dp), fontWeight = FontWeight.SemiBold)
                Icon(Icons.Filled.ChevronRight, null, tint = Muted)
            }
        }
    }
}
