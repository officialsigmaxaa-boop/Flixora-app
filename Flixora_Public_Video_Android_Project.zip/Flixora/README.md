# Flixora Android starter — Public Catalog Edition

Native Kotlin + Jetpack Compose Android starter.

## Public video source
The Home feed now queries the Internet Archive Advanced Search API for movie-type items with a license URL. Selecting an item fetches its metadata and looks for an MP4/OGV media file; MP4 playback uses AndroidX Media3 ExoPlayer. The app shows the reported license URL and source attribution.

API references:
- Internet Archive developer resources: https://archivesupport.zendesk.com/hc/en-us/articles/360001495812-Developer-Resources
- Advanced Search API: https://doc-tools.readthedocs.io/en/latest/item-search-apis.html
- Metadata API: https://doc-tools.readthedocs.io/en/latest/metadata.html

## Current functionality
- Live Internet Archive public catalog search
- Search by title/creator/subject
- Metadata lookup and direct MP4 playback when an MP4 is available
- Android DownloadManager downloads for recognized CC BY / CC BY-SA / CC public-domain license URL patterns
- License URL shown with each item
- Dark premium Flixora interface
- Explore categories and app navigation
- Shorts, Downloads and Library screens are UI foundations

## Build
Open in Android Studio with Android SDK Platform 35 installed, sync Gradle, then Build > Build APK(s).
Debug APK output after successful build: `app/build/outputs/apk/debug/app-debug.apk`

## Important rights and production notes
Internet Archive metadata and uploader-provided license information are not a substitute for legal review. This prototype only exposes a download URL when it recognizes a small set of CC BY, CC BY-SA, or Creative Commons public-domain license URL patterns; a production app must verify the exact item license, attribution requirements, territory, and rights before offering downloads. Playback availability depends on the archive item having a supported media file.

YouTube API audiovisual content must not be downloaded, cached for offline playback, or used to circumvent YouTube restrictions. YouTube videos, if ever integrated, must use approved embedded playback and comply with YouTube API branding and player policies:
- https://developers.google.com/youtube/terms/developer-policies
- https://www.youtube.com/t/terms

This is not yet a complete production streaming service. Authentication, persistent playlists/history, true vertical short-form discovery, secure download manager, creator uploads, moderation, backend, CDN, privacy policy and Play Store review remain to be implemented.
